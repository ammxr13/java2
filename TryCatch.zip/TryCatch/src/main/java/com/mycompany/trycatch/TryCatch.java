/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trycatch;

/**
 *
 * @author Ammar
 */
public class TryCatch {

    public static void main(String[] args) {
       try {
            String[] Month = {"Jan", "Feb", "Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
            System.out.println(Month[12]);
        }
        
        catch (Exception ex) {
            System.out.println("No month after December/before January");
        }
    }
}
